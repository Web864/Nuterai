import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Loader2, Leaf } from "lucide-react";

// Captured at module evaluation time, before the router's own hydration can
// touch window.location (a known class of bug: SPA routers reconstructing
// the URL from their internal {pathname, search} model can silently drop a
// hash fragment they don't track, and by the time a useEffect runs it may
// already be gone). exchangeCodeForSession/setSession below use these
// snapshots instead of re-reading window.location live.
const capturedSearch = typeof window !== "undefined" ? window.location.search : "";
const capturedHash = typeof window !== "undefined" ? window.location.hash : "";
const PASSWORD_RECOVERY_STORAGE_KEY = "nutriai:password-recovery-session";

const search = z.object({ next: z.string().optional() });

export const Route = createFileRoute("/auth_/callback")({
  validateSearch: search,
  head: () => ({
    meta: [{ title: "Signing you in — NutriAI" }, { name: "robots", content: "noindex" }],
  }),
  component: CallbackPage,
});

function CallbackPage() {
  const { next } = Route.useSearch();

  useEffect(() => {
    let cancelled = false;

    async function finish() {
      // Don't rely solely on supabase-js's own auto-detection (which reads
      // window.location fresh, at whatever moment its lazily-constructed
      // client happens to initialize) — exchange explicitly using the
      // snapshot taken at module load. Covers both PKCE (email confirmation,
      // OAuth — this client uses flowType: "pkce") and, defensively, any
      // legacy implicit-flow hash tokens.
      const params = new URLSearchParams(capturedSearch);
      const code = params.get("code");
      const oauthError = params.get("error_description") || params.get("error");
      const hashParams = new URLSearchParams(capturedHash.replace(/^#/, ""));
      const hashError =
        hashParams.get("error_description") ||
        hashParams.get("error_code") ||
        hashParams.get("error");
      const access_token = hashParams.get("access_token");
      const refresh_token = hashParams.get("refresh_token");

      // Temporary diagnostics — presence/booleans only, never values. Remove
      // once the production sign-in failure this was added for is confirmed
      // fixed or its real cause is captured.
      const hasVerifier = Object.keys(localStorage).some((k) => k.endsWith("-code-verifier"));
      console.info("[auth/callback] reached", {
        origin: window.location.origin,
        pathname: window.location.pathname,
        hasCode: !!code,
        hasAuthError: !!(oauthError || hashError),
        hasHashTokens: !!(access_token && refresh_token),
        hasVerifier,
      });

      let exchangeError: { message: string; name?: string; status?: number; code?: string } | null =
        null;
      // Trust the session returned directly by the exchange call itself
      // (already in-memory the instant it resolves) instead of re-reading
      // getSession() afterwards — that was a needless indirection that only
      // added a timing dependency without adding correctness.
      let session: Awaited<ReturnType<typeof supabase.auth.getSession>>["data"]["session"] = null;
      if (oauthError || hashError) {
        exchangeError = { message: oauthError || hashError || "Authentication link failed." };
      } else if (code) {
        const { data, error } = await supabase.auth.exchangeCodeForSession(code);
        exchangeError = error;
        session = data.session ?? null;
      } else if (access_token && refresh_token) {
        const { data, error } = await supabase.auth.setSession({ access_token, refresh_token });
        exchangeError = error;
        session = data.session ?? null;
      }

      if (exchangeError) {
        // status/code/name are structured AuthError fields (never the code,
        // verifier, or a token) — this is what actually identifies *why*
        // Supabase rejected the exchange, which .message alone has not been
        // enough to pin down in prior production failures.
        console.error("[auth/callback] sign-in failed", {
          message: exchangeError.message,
          name: exchangeError.name,
          status: exchangeError.status,
          code: exchangeError.code,
        });
      }

      // Fallback only: give storage a brief moment in case the exchange
      // succeeded but didn't hand back a session synchronously.
      if (!session) {
        for (let i = 0; i < 10; i++) {
          const { data } = await supabase.auth.getSession();
          if (data.session) {
            session = data.session;
            break;
          }
          await new Promise((r) => setTimeout(r, 150));
        }
      }
      if (cancelled) return;

      console.info("[auth/callback] result", {
        hadExchangeError: !!exchangeError,
        foundSession: !!session,
      });

      if (!session) {
        const isPasswordReset = next === "/auth/reset-password";
        toast.error(callbackErrorMessage(exchangeError?.message, isPasswordReset));
        window.location.replace(
          isPasswordReset ? "/auth/forgot-password?error=invalid-reset-link" : "/auth",
        );
        return;
      }
      const target = next && next.startsWith("/") && !next.startsWith("//") ? next : "/dashboard";
      if (target === "/auth/reset-password") {
        sessionStorage.setItem(PASSWORD_RECOVERY_STORAGE_KEY, "true");
      }
      window.location.replace(target);
    }
    finish();
    return () => {
      cancelled = true;
    };
  }, [next]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-hero">
      <div className="flex flex-col items-center gap-4 text-primary-foreground">
        <h1 className="sr-only">Verifying your account</h1>
        <span className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-primary-foreground/10 backdrop-blur">
          <Leaf className="h-6 w-6" />
        </span>
        <Loader2 className="h-6 w-6 animate-spin" />
        <p className="text-sm opacity-80">Signing you in…</p>
      </div>
    </div>
  );
}

function callbackErrorMessage(message = "", isPasswordReset = false): string {
  const lower = message.toLowerCase();
  const linkLabel = isPasswordReset ? "password reset link" : "confirmation link";

  if (lower.includes("expired")) {
    return `${linkLabel} has expired. Please request a new ${isPasswordReset ? "reset" : "confirmation"} email.`;
  }
  if (lower.includes("invalid") || lower.includes("token") || lower.includes("otp")) {
    return `This ${linkLabel} is invalid or has already been used.`;
  }
  if (lower.includes("code verifier") || lower.includes("pkce")) {
    return `This ${linkLabel} could not be completed in this browser. Please request a new ${isPasswordReset ? "reset" : "confirmation"} email and open it in the same browser.`;
  }
  if (lower.includes("access_denied")) {
    return "Confirmation was cancelled or denied. Please try the confirmation link again.";
  }
  if (lower.includes("network") || lower.includes("fetch") || lower.includes("failed to")) {
    return isPasswordReset
      ? "Network error while resetting your password. Check your connection and try again."
      : "Network error while confirming your account. Check your connection and try again.";
  }

  return isPasswordReset
    ? "Password reset link failed. Please request a new reset email."
    : "Confirmation link failed. Please request a new confirmation email.";
}
