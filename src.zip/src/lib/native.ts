/**
 * Native-shell bootstrap for the Capacitor Android build. No-ops entirely on
 * web (Capacitor.isNativePlatform() is false there), so this file never
 * changes browser/PWA behavior.
 */
import { Capacitor } from "@capacitor/core";
import type { AnyRouter } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { DARK_THEME_COLOR, LIGHT_THEME_COLOR, type ResolvedTheme } from "@/lib/theme";

export const isNative = Capacitor.isNativePlatform();

/** Custom-scheme deep link Google/Supabase redirect back into after native OAuth. */
export const OAUTH_REDIRECT_URL = "nutriai://auth-callback";
const PASSWORD_RECOVERY_STORAGE_KEY = "nutriai:password-recovery-session";

let initialized = false;

export async function initializeNative(router: AnyRouter): Promise<void> {
  if (!isNative || initialized) return;
  initialized = true;

  const [{ SplashScreen }, { App }] = await Promise.all([
    import("@capacitor/splash-screen"),
    import("@capacitor/app"),
  ]);

  await applyNativeTheme(document.documentElement.classList.contains("dark") ? "dark" : "light");

  void setupNetworkStatus();

  // Hide the launch splash once the first real paint has happened, instead
  // of a fixed timer — avoids a blank-white flash while the SSR page loads
  // over the network.
  requestAnimationFrame(() => {
    void SplashScreen.hide();
  });

  // Hardware/gesture back button: go back through router history, or exit
  // the app when there's nowhere left to go (standard Android behavior).
  App.addListener("backButton", ({ canGoBack }) => {
    if (canGoBack) {
      router.history.back();
    } else {
      void App.exitApp();
    }
  });

  // OAuth callback: Google refuses to authenticate inside an embedded
  // WebView, so native sign-in opens the system browser (see handleGoogle in
  // routes/auth.tsx) and Supabase redirects back to this custom scheme
  // instead of a web URL. Capture it here, exchange the code for a session,
  // and hand off to the router — this event never becomes a normal route.
  App.addListener("appUrlOpen", ({ url }) => {
    if (!url.startsWith(OAUTH_REDIRECT_URL)) return;
    void handleOAuthCallback(url, router);
  });
}

/**
 * React Query's default online detection (navigator.onLine + window
 * online/offline events) is unreliable inside an Android WebView, which
 * silently breaks its automatic refetch-on-reconnect behavior. Capacitor's
 * Network plugin reads the OS-level connection state instead.
 */
export async function applyNativeTheme(resolved: ResolvedTheme): Promise<void> {
  if (!isNative) return;

  const { StatusBar, Style } = await import("@capacitor/status-bar");
  await StatusBar.setStyle({ style: resolved === "dark" ? Style.Dark : Style.Light }).catch(
    () => {},
  );
  await StatusBar.setBackgroundColor({
    color: resolved === "dark" ? DARK_THEME_COLOR : LIGHT_THEME_COLOR,
  }).catch(() => {});
}

async function setupNetworkStatus(): Promise<void> {
  const [{ Network }, { onlineManager }] = await Promise.all([
    import("@capacitor/network"),
    import("@tanstack/react-query"),
  ]);

  onlineManager.setEventListener((setOnline) => {
    const subPromise = Network.addListener("networkStatusChange", (status) => {
      setOnline(status.connected);
    });
    return () => {
      void subPromise.then((sub) => sub.remove());
    };
  });

  const status = await Network.getStatus();
  onlineManager.setOnline(status.connected);
}

async function handleOAuthCallback(url: string, router: AnyRouter): Promise<void> {
  const { Browser } = await import("@capacitor/browser");
  await Browser.close().catch(() => {});

  const parsed = new URL(url.replace("nutriai://", "https://placeholder/"));
  const code = parsed.searchParams.get("code");
  const errorDescription = parsed.searchParams.get("error_description");
  const next = parsed.searchParams.get("next");
  const target = next && next.startsWith("/") && !next.startsWith("//") ? next : "/dashboard";

  if (errorDescription) {
    const { toast } = await import("sonner");
    toast.error(errorDescription);
    return;
  }
  if (!code) return;

  const { error } = await supabase.auth.exchangeCodeForSession(code);
  if (error) {
    const { toast } = await import("sonner");
    toast.error("Sign-in failed. Please try again.");
    return;
  }
  if (target === "/auth/reset-password") {
    sessionStorage.setItem(PASSWORD_RECOVERY_STORAGE_KEY, "true");
  }
  await router.navigate({ to: target as "/auth/reset-password" | "/dashboard", replace: true });
}
